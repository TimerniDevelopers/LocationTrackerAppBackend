<div class="col-sm-6 mb-2">
    <label class="control-label">Patient Name <span class="text-danger">*</span></label>
    <input type="text" name="name" disabled class="form-control" value="{{ $patient->name }}">
</div>
<div class="col-sm-6 mb-2">
    <label class="control-label">Patient Phone Number <span class="text-danger">*</span></label>
    <input type="text" name="phone" disabled class="form-control" value="{{ $patient->phone }}">
</div>
