<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
     google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([

            ['Task', 'Hours per Day'],
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $questionAnswer = DB::table('question_answer')->where('question_id', $type->id)->count();
            ?>
                <?php if($loop->last): ?>
                    ['<?php echo e($type->name); ?>',    <?php echo e($questionAnswer); ?>]
                <?php else: ?>
                    ['<?php echo e($type->name); ?>',    <?php echo e($questionAnswer); ?>],
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]);

        var options = {
          title: 'Question Answer Analytics'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart2'));

        chart.draw(data, options);
      }
    </script>
    <script type="text/javascript">
     google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([

            ['Task', 'Hours per Day'],
            <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $questionAnswer = DB::table('question_answer')->where('question_id', $type->id)->count();
            ?>
                <?php if($loop->last): ?>
                    ['<?php echo e($type->name); ?>',    <?php echo e($questionAnswer); ?>]
                <?php else: ?>
                    ['<?php echo e($type->name); ?>',    <?php echo e($questionAnswer); ?>],
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]);

        var options = {
          title: 'Question Answer Analytics'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart3'));

        chart.draw(data, options);
      }
    </script>
<?php /**PATH C:\xampp\htdocs\LocationTrackerAppBackend\core\resources\views/backend/questionAnswer/admin-analytics.blade.php ENDPATH**/ ?>