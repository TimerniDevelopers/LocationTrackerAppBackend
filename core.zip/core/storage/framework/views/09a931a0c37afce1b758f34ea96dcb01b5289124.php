

<?php $__env->startSection('title'); ?>
    Start Survey | DcoTrack
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $i = 1; ?>
    <div class="content-wrapper" style="font-family: Roboto">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-12">
                        <h1 class="m-0 text-dark" style="font-family: kalpurush">Survey</h1>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <section class="content">
            <div class="col-sm-12">
                <div class="card">
                    <div class="container-fluid mt-2 mb-3">
                        <form action="<?php echo e(route('submit.survey')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <input type="hidden" name="question_length" value="<?php echo e($inputQuestions->count()); ?>">
                                <?php $__currentLoopData = $inputQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $inputQuestion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($inputQuestion->type == 1): ?>
                                        <div class="form-group col-sm-6">
                                            <label class="control-label"><?php echo e($i++); ?>.
                                                <?php echo e($inputQuestion->name); ?></label>
                                            <input type="text" name="input_ans<?php echo e($index + 1); ?>" value=""
                                                class="form-control">
                                            <input type="hidden" name="question_id<?php echo e($index + 1); ?>"
                                                value="<?php echo e($inputQuestion->id); ?>" class="form-control">
                                            <input type="hidden" name="question_type<?php echo e($index + 1); ?>"
                                                value="<?php echo e($inputQuestion->type); ?>" class="form-control">
                                        </div>
                                    <?php endif; ?>

                                    <?php if($inputQuestion->type == 3): ?>
                                        <div class="form-group col-sm-6">
                                            <label class="control-label"><?php echo e($i++); ?>.
                                                <?php echo e($inputQuestion->name); ?></label>
                                            <?php $__currentLoopData = $inputQuestion->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $mcqItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio"
                                                        name="mcq_ans<?php echo e($index + 1); ?>" value="<?php echo e($mcqItem->option); ?>"
                                                        id="mcqQue<?php echo e($mcqItem); ?>">
                                                    <label class="form-check-label" for="mcqQue<?php echo e($mcqItem); ?>">
                                                        <?php echo e($mcqItem->option); ?>

                                                    </label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" name="question_type<?php echo e($index + 1); ?>"
                                                value="<?php echo e($inputQuestion->type); ?>" class="form-control">
                                            <input type="text" name="others<?php echo e($index + 1); ?>" class="form-control"
                                                placeholder="If others type here">
                                            <input type="hidden" name="question_id<?php echo e($index + 1); ?>"
                                                value="<?php echo e($inputQuestion->id); ?>" class="form-control">
                                        </div>
                                    <?php endif; ?>

                                    <?php if($inputQuestion->type == 4): ?>
                                        <div class="form-group col-sm-6">
                                            <label class="control-label"><?php echo e($i++); ?>.
                                                <?php echo e($inputQuestion->name); ?></label>
                                            <?php $__currentLoopData = $inputQuestion->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $checkboxItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox"
                                                        name="checkbox_ans<?php echo e($index + 1); ?>"
                                                        value="<?php echo e($checkboxItem->option); ?>"
                                                        id="defaultCheck<?php echo e($checkboxItem->id); ?>">
                                                    <label class="form-check-label"
                                                        for="defaultCheck<?php echo e($checkboxItem->id); ?>">
                                                        <?php echo e($checkboxItem->option); ?>

                                                    </label>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" name="question_type<?php echo e($index + 1); ?>"
                                                value="<?php echo e($inputQuestion->type); ?>" class="form-control">
                                            <input type="text" name="others<?php echo e($index + 1); ?>" class="form-control"
                                                placeholder="If others type here">
                                            <input type="hidden" name="question_id<?php echo e($index + 1); ?>"
                                                value="<?php echo e($inputQuestion->id); ?>" class="form-control">
                                        </div>
                                    <?php endif; ?>

                                    <?php if($inputQuestion->type == 2): ?>
                                        <div class="form-group col-sm-6">
                                            <label class="control-label d-block"><?php echo e($i++); ?>.
                                                <?php echo e($inputQuestion->name); ?></label>
                                            <select name="dropdown_ans<?php echo e($index + 1); ?>" class="form-control">
                                                <option selected disabled>Select Option</option>
                                                <?php $__currentLoopData = $inputQuestion->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dropdownItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($dropdownItem->option); ?>">
                                                        <?php echo e($dropdownItem->option); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <input type="hidden" name="question_type<?php echo e($index + 1); ?>"
                                                value="<?php echo e($inputQuestion->type); ?>" class="form-control">
                                            <input type="hidden" name="question_id<?php echo e($index + 1); ?>"
                                                value="<?php echo e($inputQuestion->id); ?>" class="form-control">
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="form-group m-auto">
                                <div class="col-sm-4">
                                    <button class="btn btn-primary">Submit Survey</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\LocationTrackerAppBackend\core\resources\views/user/survey/start-survey.blade.php ENDPATH**/ ?>