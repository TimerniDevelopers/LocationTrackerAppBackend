<footer id="footer-area">
        <div class="container">
          <div class="row">
            <div class="col-md-5 col-lg-7 d-flex align-items-center sm-center">
              <div class="footer-img">
                <a href="{{ route('index') }}">

                  <img src="{{ asset('assets/organization_frontend/img/dcotrak.png') }}" alt="logo">
                </a>
              </div>
            </div>
            <div class="col-md-7 col-lg-5">
              <div class="foter-content">
                <ul>
                  <li>
                    <a href="https://timerni.com/about_us" target="_blank">About us  </a>
                  </li>
                  <li>
                    <a href="javascrip:void(0);">Request a Demo  </a>
                  </li>
                  <li>
                    <a href="javascrip:void(0);"></a>
                  </li>
                </ul>
                <ul>
                  <li>
                    <a href="{{ route('contact') }}"> Contact us</a>
                  </li>
                  <li>
                    <a href="https://timerni.com/policy" target="_blank"> Terms & conditions</a>
                  </li>
                  <li>
                    <a href="#"></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div class="copyright text-center mt-3">

            <p > <i class="fas fa-copyright"></i>
            All rights reserved to <img src="{{ asset('assets/organization_frontend/img/sitelogo.png') }}" alt="Tri" style="max-height: 20px;">
            <a href="https://timerni.com" target="_blank">Time research & innovation</a>.
          </p>
          </div>

        </div>
      </footer>
