<script src="{{ asset('assets/backend/js/select2.min.js') }}"></script>
<link rel="stylesheet" href="{{ asset('assets/backend/css/select2.min.css') }}">
<script>
    $(document).ready(function () {
        $('.select2').select2();
    });
</script>
